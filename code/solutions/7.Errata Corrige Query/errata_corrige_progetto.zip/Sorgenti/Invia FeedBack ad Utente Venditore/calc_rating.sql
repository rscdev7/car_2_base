delimiter //
CREATE PROCEDURE uk (IN ven VARCHAR(16)) 
BEGIN 
	DECLARE U INT DEFAULT 5;
	DECLARE somma FLOAT DEFAULT 1.0;
	DECLARE NUM FLOAT DEFAULT 2.0;
	DECLARE o CURSOR FOR (SELECT SUM(f.valutazione) AS Somma,COUNT(*) AS N
						  FROM FeedBack AS f,Riceve_F_Ve AS ric
		                  WHERE f.Cod_Mes=ric.Cod_FeedBack
		                  AND STRCMP(ric.Cod_Venditore,ven)=0);
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET U=0;
	OPEN o;
	IF (U=5) THEN
			FETCH o INTO somma,NUM;
			IF (U=5)THEN			
				UPDATE Utente_Venditore SET Rating=(somma/NUM) WHERE STRCMP(CF_P_IVA,ven)=0;
			END IF;
		END IF;
		CLOSE o;
END;
//
delimiter ;