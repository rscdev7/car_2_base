CALL o26_auto(
1,
"WRPT44HJPZZ",
"L'auto era in buone condizioni",
8,
'2017-02-15 20:20:30',
1,
"Porsche",
"911",
"GT2 RS",
@val
);