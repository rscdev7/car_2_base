(SELECT w.Marca,w.Modello,w.Serie
FROM Annunci_Auto AS a,Auto_Ve_X_Ann AS w
WHERE w.Cod_Annuncio=a.Cod_Annuncio 
AND a.Cancellato=FALSE
AND STRCMP(w.Codice_Venditore,"WRPT44HJPZZ")=0)

UNION

(SELECT w.Cod_ricambio,"",""
FROM Annunci_Ricambi AS a,Ric_Ve_X_Ann AS w
WHERE w.Cod_Annuncio=a.Cod_Annuncio 
AND a.Cancellato=FALSE
AND STRCMP(w.Cod_Venditore,"WRPT44HJPZZ")=0);