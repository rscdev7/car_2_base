CALL o22_u(
"prova@gmail.com",
"123",
"Chrome",
"Desktop",
"192.168.0.0",
'2017-02-05',
@val
);