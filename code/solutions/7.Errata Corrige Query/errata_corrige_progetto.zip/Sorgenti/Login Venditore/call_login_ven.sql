CALL o22_v(
"info_cars@outlook.com",
"123",
"Safari",
"Mobile",
"192.168.0.0",
'2017-01-05',
@val
);