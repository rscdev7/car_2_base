(SELECT a.Cod_Prod,a.Cod_Venditore,a.Marca,a.Modello,a.Serie
FROM Invia_F_Ut AS f,FeedBack AS p,Auto_X_FeedBack AS a
WHERE f.Cod_Feedback=p.Cod_Mes
AND (p.valutazione IS NOT NULL)
AND p.Cod_Mes=a.FeedBack
AND f.Codice_Utente=1
)

UNION

(SELECT a.Cod_Prod,a.Cod_Venditore,a.Cod_Ricambio,"",""
FROM Invia_F_Ut AS f,FeedBack AS p,Ricambi_X_FeedBack AS a
WHERE f.Codice_Utente=1
AND f.Cod_FeedBack=p.Cod_Mes
AND p.Valutazione IS NOT NULL
AND p.Cod_Mes=a.FeedBack
);