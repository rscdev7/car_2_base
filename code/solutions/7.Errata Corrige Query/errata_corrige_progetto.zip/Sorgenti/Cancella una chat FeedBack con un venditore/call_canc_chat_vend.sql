CALL o39(
1,
"WRPT44HJPZZ",
@val
);