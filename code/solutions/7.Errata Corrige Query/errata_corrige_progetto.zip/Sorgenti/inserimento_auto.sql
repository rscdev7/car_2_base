INSERT INTO Auto VALUES("Nissan","Micra","2017","compatta");
INSERT INTO Auto VALUES("Nissan","GTR","2016","Berlina");
INSERT INTO Auto VALUES("Toyota","Yaris","2016","compatta");
INSERT INTO Auto VALUES("Honda","NSX","2017","Coupe 2 Posti");
INSERT INTO Auto VALUES("Ford","Fiesta","2017","compatta");
INSERT INTO Auto VALUES("Ford","Mustang","GT","Muscle Car");
INSERT INTO Auto VALUES("Chevrolet","Corvette","Z06","Coupe a 2 Posti");
INSERT INTO Auto VALUES("Tesla","Model S","P90D","Berlina");
INSERT INTO Auto VALUES("Abarth","124","Spider","Coupe a 2 Posti");
INSERT INTO Auto VALUES("FIAT","Panda","Terza Serie","compatta");
INSERT INTO Auto VALUES("Alfa Romeo","Giulietta","2010","compatta");
INSERT INTO Auto VALUES("Alfa Romeo","Giulia","Quadrifoglio","Berlina");
INSERT INTO Auto VALUES("Nissan","Micra","2017","citycar");
INSERT INTO Auto VALUES("Ferrari","488","GTB","Coupe a 2 Posti");
INSERT INTO Auto VALUES("Maserati","Ghibli","GTS","Berlina");
INSERT INTO Auto VALUES("Lamborghini","Aventador","S","Coupe a 2 Posti");
INSERT INTO Auto VALUES("Lamborghini","Huracan","Performante","Coupe a 2 Post");
INSERT INTO Auto VALUES("Citroen","C3","2017","compatta");
INSERT INTO Auto VALUES("Peugeoute","208","GT Line","compatta");
INSERT INTO Auto VALUES("Mini","Cooper","John CooperWork","compatta");
INSERT INTO Auto VALUES("Jaguar","XJ","2014","Berlina");
INSERT INTO Auto VALUES("Mercedes-Benza","Classe A","Terza Serie","compatta");
INSERT INTO Auto VALUES("Audi","A1","2014","compatta");
INSERT INTO Auto VALUES("Porsche","911","GT2 RS","Coupe a 2 Posti");
INSERT INTO Auto VALUES("Porsche","Panamera","Turbo","Berlina");
INSERT INTO Auto VALUES("BMW","Serie 1","2015","Compatta");
INSERT INTO Auto VALUES("BMW","Serie 3","2012","Berlina");


