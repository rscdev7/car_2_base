CALL o23(
'2018-02-25 18:13:02',
"Mario",
"Rossi",
"Italiana",
"prova@gmail.com",
"123",
"Sicilia",
"CT",
"Catania"
);