CALL o28_auto(
"WRPT44HJPZZ",
"prova@gmail.com",
"Ciao, lascia un feedback sul tuo ac",
1,
"Porsche",
'911',
"GT2 RS",
'2017-02-15 20:20:30',
@val
);