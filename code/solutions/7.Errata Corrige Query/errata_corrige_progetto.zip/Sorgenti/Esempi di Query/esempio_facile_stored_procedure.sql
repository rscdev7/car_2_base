delimiter //
CREATE PROCEDURE uk () 
BEGIN 
END;
//
delimiter ;