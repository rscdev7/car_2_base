/*CREATE TABLE Banca(
	IDconto int(11) NOT NULL,
	Descrizione VARCHAR(30),
	D DATETIME NOT NULL,
	PRIMARY KEY (IDconto),
	KEY (IDconto)
)ENGINE=InnoDB*/

/*INSERT INTO Banca VALUES (123,"Hhhhhh",'2017-02-20 20:54:03 ');*/
SELECT DATE (D) FROM Banca;