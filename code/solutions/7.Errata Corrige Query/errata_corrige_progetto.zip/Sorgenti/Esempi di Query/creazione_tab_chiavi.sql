CREATE TABLE Banca(
	IDconto int(11) NOT NULL,
	Descrizione VARCHAR(30) NOT NULL,
	PRIMARY KEY (IDconto),
	KEY (IDconto)
)ENGINE=InnoDB;

CREATE TABLE Pers(
	CF int(16) NOT NULL,
	Descrizione VARCHAR(30) NOT NULL,
	Z int(11) NOT NULL,
	W int(11) NOT NULL,
	PRIMARY KEY (CF),
	FOREIGN KEY (Z) REFERENCES Banca(IDconto),
	KEY (CF)
)ENGINE=InnoDB;

CREATE TABLE t(
	a int(11) NOT NULL,
	PRIMARY KEY (a),
	KEY (a)
)ENGINE=InnoDB;

CREATE TABLE n(
	f int(11) NOT NULL,
	PRIMARY KEY (f),
	KEY (f)
)ENGINE=InnoDB;
