CALL o24(
'2015-09-15 08:13:02',
"WRPT44HJPZZ",
'1989-07-15',
"Cars LTD",
NULL,
"info_cars@outlook.com",
"123",
"0984525684",
"Italiana",
"Lombardia",
"MI",
"Milano",
"Via Ansperto"
);